use anchor_lang::prelude::*;

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

#[program]
pub mod type_cosplay_secure {
    use super::*;

    pub fn update_user(ctx: Context<UpdateUser>) -> Result<()> {
        let user = User::try_from_slice(&ctx.accounts.user.data.borrow()).unwrap();
        if ctx.accounts.user.owner != ctx.program_id {
            return Err(ProgramError::IllegalOwner.into());
        }
        if user.authority != ctx.accounts.authority.key() {
            return Err(ProgramError::InvalidAccountData.into());
        }
        if user.discriminant != AccountDiscriminant::User {
            return Err(ProgramError::InvalidAccountData.into());
        }
        msg!("GM {}", user.authority);
        Ok(())
    }
}

#[derive(Accounts)]
pub struct UpdateUser<'info> {
    /// CHECK: PORT - doc exigido pelo Anchor >= 0.24; sem efeito na logica
    user: AccountInfo<'info>,
    authority: Signer<'info>,
}

#[derive(AnchorSerialize, AnchorDeserialize)] // PORT: Borsh* -> Anchor* (mesmo borsh)
pub struct User {
    discriminant: AccountDiscriminant,
    authority: Pubkey,
}

#[derive(AnchorSerialize, AnchorDeserialize)]
pub struct Metadata {
    discriminant: AccountDiscriminant,
    account: Pubkey,
}

#[derive(AnchorSerialize, AnchorDeserialize, PartialEq)]
pub enum AccountDiscriminant {
    User,
    Metadata,
}
