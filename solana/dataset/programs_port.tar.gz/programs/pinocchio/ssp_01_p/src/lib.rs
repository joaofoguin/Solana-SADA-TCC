// preenchido por prepare.sh a partir do SSP (copia sem alteracao)
